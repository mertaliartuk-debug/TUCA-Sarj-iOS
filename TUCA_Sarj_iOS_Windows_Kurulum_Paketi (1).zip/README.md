# TÜÇA Şarj — gerçek iPhone (SwiftUI) kaynak projesi

Bu paket **yerel (native) iOS uygulaması** kaynak kodudur; web sayfası/PWA değildir. Apple imzalı `.ipa` içermez.

## Mac'te oluşturma
1. Mac'e Apple Xcode (iOS 16+ destekleyen sürüm) ve [XcodeGen](https://github.com/yonaskolb/XcodeGen) yükleyin.
2. Terminal'de bu klasöre gidin ve `xcodegen generate` çalıştırın. Bu işlem `TUCASarj.xcodeproj` oluşturur.
3. `TUCASarj.xcodeproj` dosyasını Xcode ile açın.
4. Signing & Capabilities bölümünde kendi Apple takımınızı seçin ve Bundle Identifier değerini size özel bir değerle değiştirin.
5. iPhone'u Mac'e bağlayın; hedef olarak iPhone'u seçip Run'a basın. iPhone'da Developer Mode gerekebilir.
6. TestFlight/App Store için Apple Developer Program, imzalama, gizlilik ve App Review işlemleri ayrıca gereklidir.

## Özellikler
- SwiftUI sekmeli yerel arayüz: Özet, Kullanıcılar, Tüketim, Bildirimler, Ayarlar
- Kişi / plaka / RFID / e-posta kaydı
- Manuel şarj kaydı ve kWh × birim fiyat hesaplama
- CSV ile şarj kayıtlarını içe aktarma (aynı satırın tekrar eklenmesini önlemeye yönelik kontrol)
- Tahsilat, kısmi ödeme, bakiye, geciken bildirim sayısı
- 3 gün vadeli **taslak** ödeme bildirimi PDF'si ve iOS paylaşım menüsü
- Cihaz içi JSON veri saklama

## CSV biçimi
Başlık: `ad;plaka;rfid;eposta;tarih;kwh;birim_fiyat;istasyon`
Örnek: `Örnek Kullanıcı;06ABC123;RFID001;ornek@example.com;14.10.2026;22,5;6,00;AC 1`
Tarih `gg.aa.yyyy` veya ISO-8601 olmalıdır. Dosya noktalı virgül veya virgülle ayrılabilir. Kullanıcı eşleştirmesi plakaya göre yapılır.

## Sınırlamalar
- Önceki dört Windows `.exe` dosyası iOS'ta çalıştırılamaz; bu uygulama ayrı bir SwiftUI yeniden geliştirmesidir.
- Şarj cihazları/OCPP ile canlı bağlantı, kurum veritabanı, kullanıcı girişi, e-posta sunucusundan otomatik gönderim ve otomatik PDF arşivleme **henüz yoktur**.
- PDF, icra ödeme emri veya resmî tebliğ yerine geçmez. 3 günlük süre uygulamada oluşturulma tarihinden hesaplanır; gerçek tebliğ tarihi kurumca doğrulanmalıdır.
- Birim fiyat başlangıçta örnek değerdir; yetkili kurum fiyatını girin.
- Bu ortamda macOS/Xcode bulunmadığından derleme ve cihaz testi yapılmamıştır. Kurumsal dağıtım öncesi Mac üzerinde test şarttır.
