import SwiftUI

@main struct TUCASarjApp: App {
    @StateObject private var store = AppStore()
    var body: some Scene {
        WindowGroup {
            MainView().environmentObject(store)
                .tint(Color(red: 0.05, green: 0.39, blue: 0.33))
                .alert("Bilgi", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                    Button("Tamam", role: .cancel) { store.errorMessage = nil }
                } message: { Text(store.errorMessage ?? "") }
        }
    }
}

struct MainView: View {
    var body: some View {
        TabView {
            DashboardView().tabItem { Label("Özet", systemImage: "chart.bar.fill") }
            PeopleView().tabItem { Label("Kullanıcılar", systemImage: "person.2.fill") }
            ChargesView().tabItem { Label("Tüketim", systemImage: "bolt.car.fill") }
            NoticesView().tabItem { Label("Bildirimler", systemImage: "doc.text.fill") }
            SettingsView().tabItem { Label("Ayarlar", systemImage: "gearshape.fill") }
        }
    }
}

struct Metric: View {
    let title: String; let value: String; let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: symbol).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.title3.bold()).minimumScaleFactor(0.7).lineLimit(1)
        }.frame(maxWidth: .infinity, alignment: .leading).padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
    }
}

struct DashboardView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("TÜRKİYE ÇEVRE AJANSI").font(.caption.bold()).tracking(1.3)
                        Text("Şarj Yönetimi").font(.largeTitle.bold())
                        Text("Macunköy Yerleşkesi").font(.subheadline)
                    }.foregroundStyle(.white).frame(maxWidth: .infinity, alignment: .leading)
                        .padding(22).background(Color(red: 0.05, green: 0.39, blue: 0.33), in: RoundedRectangle(cornerRadius: 18))
                    HStack { Metric(title: "Toplam alacak", value: store.receivable.tl, symbol: "creditcard"); Metric(title: "Tahsilat", value: store.collected.tl, symbol: "checkmark.circle") }
                    HStack { Metric(title: "Tüketim", value: "\(store.consumed.quantity) kWh", symbol: "bolt"); Metric(title: "Geciken kişi", value: "\(store.overdueIDs.count)", symbol: "exclamationmark.circle") }
                    Text("Borçlu kullanıcılar").font(.headline)
                    ForEach(store.data.people.filter { store.balance($0.id) > 0.005 }.sorted { store.balance($0.id) > store.balance($1.id) }) { person in
                        HStack { VStack(alignment: .leading) { Text(person.name).font(.body.bold()); Text(person.plate).font(.caption).foregroundStyle(.secondary) }
                            Spacer(); VStack(alignment: .trailing) { Text(store.balance(person.id).tl).bold(); if store.overdueIDs.contains(person.id) { Text("Gecikti").font(.caption).foregroundStyle(.red) } } }
                        .padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                    }
                    if store.data.people.isEmpty { ContentUnavailableView("Henüz kayıt yok", systemImage: "tray", description: Text("Kullanıcı ekleyin veya CSV içe aktarın.")) }
                }.padding()
            }.background(Color(.systemGroupedBackground)).navigationTitle("Genel Bakış")
        }
    }
}

struct PeopleView: View {
    @EnvironmentObject var store: AppStore
    @State private var adding = false
    var body: some View {
        NavigationStack {
            List(store.data.people) { person in
                NavigationLink { PersonDetail(personID: person.id) } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(person.name).font(.headline)
                        Text("\(person.plate) • \(store.balance(person.id).tl) bakiye").font(.subheadline).foregroundStyle(.secondary)
                    }.padding(.vertical, 4)
                }
            }.navigationTitle("Kullanıcılar")
                .toolbar { Button { adding = true } label: { Image(systemName: "plus") } }
                .sheet(isPresented: $adding) { AddPersonView() }
        }
    }
}

struct AddPersonView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var name = "", plate = "", rfid = "", email = ""
    var body: some View {
        NavigationStack {
            Form {
                TextField("Ad Soyad", text: $name)
                TextField("Plaka", text: $plate).textInputAutocapitalization(.characters)
                TextField("RFID kart", text: $rfid)
                TextField("E-posta", text: $email).keyboardType(.emailAddress).textInputAutocapitalization(.never)
            }.navigationTitle("Yeni Kullanıcı")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Vazgeç") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Kaydet") {
                        store.data.people.append(Person(name: name.trimmingCharacters(in: .whitespaces), plate: plate, rfid: rfid, email: email)); dismiss()
                    }.disabled(name.trimmingCharacters(in: .whitespaces).isEmpty || plate.isEmpty) }
                }
        }
    }
}

struct PersonDetail: View {
    @EnvironmentObject var store: AppStore
    let personID: UUID
    @State private var addingPayment = false
    @State private var addingCharge = false
    var body: some View {
        List {
            if let p = store.person(personID) {
                Section("Kullanıcı") { LabeledContent("Ad", value: p.name); LabeledContent("Plaka", value: p.plate); LabeledContent("RFID", value: p.rfid); LabeledContent("E-posta", value: p.email) }
                Section("Hesap") {
                    LabeledContent("Tüketim tutarı", value: store.charged(personID).tl)
                    LabeledContent("Tahsilat", value: store.paid(personID).tl)
                    LabeledContent("Kalan bakiye", value: store.balance(personID).tl)
                    Button("Ödeme Kaydet") { addingPayment = true }
                    Button("Şarj İşlemi Ekle") { addingCharge = true }
                }
                Section("Ödemeler") { ForEach(store.data.payments.filter { $0.personID == personID }.sorted { $0.date > $1.date }) { payment in
                    LabeledContent(payment.date.shortTR, value: payment.amount.tl)
                } }
            }
        }.navigationTitle("Kullanıcı Detayı")
            .sheet(isPresented: $addingPayment) { AddPaymentView(personID: personID) }
            .sheet(isPresented: $addingCharge) { AddChargeView(personID: personID) }
    }
}

struct AddPaymentView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    let personID: UUID
    @State private var amount = 0.0
    @State private var date = Date()
    @State private var note = ""
    var body: some View {
        NavigationStack {
            Form { TextField("Ödeme (TL)", value: $amount, format: .number).keyboardType(.decimalPad); DatePicker("Tarih", selection: $date, displayedComponents: .date); TextField("Açıklama", text: $note) }
                .navigationTitle("Ödeme Kaydı")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Vazgeç") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Kaydet") { store.data.payments.append(Payment(personID: personID, date: date, amount: amount, note: note)); dismiss() }.disabled(amount <= 0) } }
        }
    }
}

struct AddChargeView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    let personID: UUID
    @State private var kwh = 0.0
    @State private var price = 6.0
    @State private var station = ""
    @State private var date = Date()
    var body: some View {
        NavigationStack {
            Form { TextField("Tüketim (kWh)", value: $kwh, format: .number).keyboardType(.decimalPad); TextField("Birim fiyat (TL/kWh)", value: $price, format: .number).keyboardType(.decimalPad); TextField("İstasyon", text: $station); DatePicker("Tarih", selection: $date, displayedComponents: .date); LabeledContent("Tutar", value: (kwh * price).tl) }
                .navigationTitle("Şarj Kaydı")
                .onAppear { price = store.data.defaultUnitPrice }
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Vazgeç") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Kaydet") { store.data.charges.append(Charge(personID: personID, date: date, kwh: kwh, unitPrice: price, station: station)); dismiss() }.disabled(kwh <= 0 || price < 0) } }
        }
    }
}
