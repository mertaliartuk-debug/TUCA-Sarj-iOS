import SwiftUI
import UIKit

struct ShareFile: Identifiable { let id = UUID(); let url: URL }

@MainActor enum ReportMaker {
    static func makeNotice(person: Person, notice: Notice) throws -> URL {
        let filename = "Odeme_Bildirimi_\(person.plate.replacingOccurrences(of: " ", with: "_"))_\(UUID().uuidString.prefix(6)).pdf"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 595, height: 842))
        let pdf = renderer.pdfData { context in
            context.beginPage()
            let margin: CGFloat = 45, width: CGFloat = 505
            func draw(_ text: String, y: CGFloat, font: UIFont = .systemFont(ofSize: 12), color: UIColor = .black) -> CGFloat {
                let para = NSMutableParagraphStyle(); para.lineSpacing = 6
                let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color, .paragraphStyle: para]
                let rect = (text as NSString).boundingRect(with: CGSize(width: width, height: 700), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
                (text as NSString).draw(in: CGRect(x: margin, y: y, width: width, height: ceil(rect.height)+5), withAttributes: attrs)
                return y + ceil(rect.height) + 18
            }
            var y: CGFloat = 55
            y = draw("TÜRKİYE ÇEVRE AJANSI BAŞKANLIĞI", y: y, font: .boldSystemFont(ofSize: 17))
            y = draw("ELEKTRİKLİ ARAÇ ŞARJ İSTASYONU ÖDEME BİLDİRİMİ", y: y, font: .boldSystemFont(ofSize: 13))
            y = draw("Bildirim Tarihi: \(notice.issuedAt.shortTR)\nSon Ödeme Tarihi: \(notice.dueAt.shortTR)", y: y)
            y = draw("Sayın \(person.name),", y: y, font: .boldSystemFont(ofSize: 13))
            y = draw("Macunköy Yerleşkesi elektrikli araç şarj istasyonlarına ilişkin kayıtlar kapsamında, \(person.plate) plakalı araç için \(notice.amount.tl) tutarında ödenmemiş kullanım bedeli bulunmaktadır.", y: y)
            y = draw("29.04.2026 tarihli ve 88 sayılı Yönetim Kurulu Kararı kapsamında, bildirilen tutarın tebliğ tarihinden itibaren 3 (üç) gün içerisinde ödenmesi istenmektedir.", y: y)
            y = draw("Belirtilen süre içerisinde ödeme yapılmaması halinde, ilgili mevzuat ve kurum içi yetkilendirmeler çerçevesinde gerekli idari işlemler değerlendirilecektir.", y: y)
            y = draw("Ödenecek tutar: \(notice.amount.tl)\nPlaka: \(person.plate)\nRFID: \(person.rfid)\nAçıklama: \(notice.note)", y: y, font: .systemFont(ofSize: 12))
            _ = draw("Bilgilerinizi ve gereğini rica ederiz.\n\nTÜRKİYE ÇEVRE AJANSI BAŞKANLIĞI", y: y)
            _ = draw("Bu belge uygulamada oluşturulmuş taslaktır; resmî tebliğ veya icra ödeme emri değildir.", y: 775, font: .systemFont(ofSize: 9), color: .gray)
        }
        try pdf.write(to: url, options: .atomic)
        return url
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
