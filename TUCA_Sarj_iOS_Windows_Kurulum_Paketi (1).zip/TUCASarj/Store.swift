import Foundation
import Combine

@MainActor final class AppStore: ObservableObject {
    @Published var data = Snapshot() { didSet { save() } }
    @Published var errorMessage: String?

    private var url: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("tuca_sarj.json")
    }

    init() {
        if let bytes = try? Data(contentsOf: url), let decoded = try? JSONDecoder().decode(Snapshot.self, from: bytes) {
            data = decoded
        }
    }

    func save() {
        do { try JSONEncoder().encode(data).write(to: url, options: .atomic) }
        catch { errorMessage = "Kayıt yapılamadı: \(error.localizedDescription)" }
    }

    func person(_ id: UUID) -> Person? { data.people.first { $0.id == id } }
    func charged(_ id: UUID) -> Double { data.charges.filter { $0.personID == id }.reduce(0) { $0 + $1.total } }
    func paid(_ id: UUID) -> Double { data.payments.filter { $0.personID == id }.reduce(0) { $0 + $1.amount } }
    func balance(_ id: UUID) -> Double { charged(id) - paid(id) }
    var receivable: Double { data.people.reduce(0) { $0 + max(0, balance($1.id)) } }
    var collected: Double { data.payments.reduce(0) { $0 + $1.amount } }
    var consumed: Double { data.charges.reduce(0) { $0 + $1.kwh } }
    var overdueIDs: Set<UUID> {
        Set(data.notices.filter { $0.dueAt < Date() && balance($0.personID) > 0.005 }.map(\.personID))
    }

    // Accept UTF-8 CSV with columns: ad,plaka,rfid,eposta,tarih,kwh,birim_fiyat,istasyon.
    // Quoted CSV cells and semicolon-separated files are supported.
    func importCSV(_ url: URL) throws -> Int {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let bytes = try Data(contentsOf: url)
        guard let text = String(data: bytes, encoding: .utf8) ?? String(data: bytes, encoding: .windowsCP1254) else {
            throw ImportError.badEncoding
        }
        let rows = text.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        guard let header = rows.first else { throw ImportError.badColumns }
        let delimiter: Character = header.filter { $0 == ";" }.count > header.filter { $0 == "," }.count ? ";" : ","
        let fields = splitCSV(header, delimiter: delimiter).map { normalize($0) }
        let required = ["ad", "plaka", "tarih", "kwh"]
        guard required.allSatisfy(fields.contains) else { throw ImportError.badColumns }
        func field(_ row: [String], _ key: String) -> String {
            guard let i = fields.firstIndex(of: key), i < row.count else { return "" }
            return row[i].trimmingCharacters(in: .whitespacesAndNewlines)
        }
        let iso = ISO8601DateFormatter()
        let df = DateFormatter(); df.locale = Locale(identifier: "tr_TR"); df.dateFormat = "dd.MM.yyyy"
        var count = 0
        var next = data
        for line in rows.dropFirst() {
            let row = splitCSV(line, delimiter: delimiter)
            let name = field(row, "ad"), plate = field(row, "plaka")
            guard !name.isEmpty, !plate.isEmpty else { continue }
            let key = plate.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
            let personID: UUID
            if let found = next.people.first(where: { $0.plate.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current) == key }) {
                personID = found.id
            } else {
                let p = Person(name: name, plate: plate, rfid: field(row, "rfid"), email: field(row, "eposta"))
                next.people.append(p); personID = p.id
            }
            let dateText = field(row, "tarih")
            let date = iso.date(from: dateText) ?? df.date(from: dateText)
            guard let date, let kwh = parseNumber(field(row, "kwh")), kwh > 0 else { continue }
            let price = parseNumber(field(row, "birim_fiyat")) ?? next.defaultUnitPrice
            let station = field(row, "istasyon")
            // Import idempotency for same person, date, amount, station.
            let exists = next.charges.contains { $0.personID == personID && $0.date == date && abs($0.kwh-kwh) < 0.00001 && $0.station == station }
            if !exists { next.charges.append(Charge(personID: personID, date: date, kwh: kwh, unitPrice: price, station: station)); count += 1 }
        }
        data = next
        return count
    }

    private func normalize(_ s: String) -> String {
        s.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().folding(options: .diacriticInsensitive, locale: Locale(identifier: "tr_TR"))
    }
    private func parseNumber(_ s: String) -> Double? {
        let cleaned = s.replacingOccurrences(of: "₺", with: "").trimmingCharacters(in: .whitespaces)
        if cleaned.contains(",") && cleaned.contains(".") { return Double(cleaned.replacingOccurrences(of: ".", with: "").replacingOccurrences(of: ",", with: ".")) }
        return Double(cleaned.replacingOccurrences(of: ",", with: "."))
    }
    private func splitCSV(_ line: String, delimiter: Character) -> [String] {
        var result: [String] = [], current = "", quoted = false
        let chars = Array(line); var i = 0
        while i < chars.count {
            let ch = chars[i]
            if ch == "\"" {
                if quoted && i+1 < chars.count && chars[i+1] == "\"" { current.append("\""); i += 1 }
                else { quoted.toggle() }
            } else if ch == delimiter && !quoted { result.append(current); current = "" }
            else { current.append(ch) }
            i += 1
        }
        result.append(current)
        return result
    }
    enum ImportError: LocalizedError {
        case badEncoding, badColumns
        var errorDescription: String? {
            switch self {
            case .badEncoding: return "Dosya UTF-8 veya Türkçe Windows metni olarak okunamadı."
            case .badColumns: return "CSV sütunları ad, plaka, tarih, kwh içermeli."
            }
        }
    }
}
