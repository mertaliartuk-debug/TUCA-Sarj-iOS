import Foundation

struct Person: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var plate: String
    var rfid: String
    var email: String
}

struct Charge: Identifiable, Codable {
    var id = UUID()
    var personID: UUID
    var date: Date
    var kwh: Double
    var unitPrice: Double
    var station: String
    var total: Double { kwh * unitPrice }
}

struct Payment: Identifiable, Codable {
    var id = UUID()
    var personID: UUID
    var date: Date
    var amount: Double
    var note: String
}

struct Notice: Identifiable, Codable {
    var id = UUID()
    var personID: UUID
    var issuedAt: Date
    var dueAt: Date
    var amount: Double
    var note: String
}

struct Snapshot: Codable {
    var people: [Person] = []
    var charges: [Charge] = []
    var payments: [Payment] = []
    var notices: [Notice] = []
    var defaultUnitPrice: Double = 6
}

extension Double {
    var tl: String { formatted(.currency(code: "TRY").locale(Locale(identifier: "tr_TR"))) }
    var quantity: String { formatted(.number.precision(.fractionLength(2)).locale(Locale(identifier: "tr_TR"))) }
}

extension Date {
    var shortTR: String { formatted(date: .numeric, time: .omitted).description }
}
