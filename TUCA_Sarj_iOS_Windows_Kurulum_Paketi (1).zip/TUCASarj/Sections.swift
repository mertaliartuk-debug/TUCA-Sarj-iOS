import SwiftUI
import UniformTypeIdentifiers

struct ChargesView: View {
    @EnvironmentObject var store: AppStore
    @State private var importing = false
    @State private var info = ""
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button { importing = true } label: { Label("CSV dosyasından şarj kayıtlarını aktar", systemImage: "square.and.arrow.down") }
                    Text("CSV sütunları: ad, plaka, rfid, eposta, tarih, kwh, birim_fiyat, istasyon").font(.caption).foregroundStyle(.secondary)
                    if !info.isEmpty { Text(info).font(.caption).foregroundStyle(.secondary) }
                }
                Section("Şarj işlemleri") {
                    ForEach(store.data.charges.sorted { $0.date > $1.date }) { charge in
                        VStack(alignment: .leading, spacing: 4) {
                            HStack { Text(store.person(charge.personID)?.name ?? "Bilinmeyen").bold(); Spacer(); Text(charge.total.tl) }
                            Text("\(charge.date.shortTR) • \(charge.kwh.quantity) kWh • \(charge.station)").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }.navigationTitle("Tüketim")
                .fileImporter(isPresented: $importing, allowedContentTypes: [.commaSeparatedText, .plainText]) { result in
                    do { let count = try store.importCSV(result.get()); info = "\(count) yeni şarj işlemi aktarıldı." }
                    catch { store.errorMessage = error.localizedDescription }
                }
        }
    }
}

struct NoticesView: View {
    @EnvironmentObject var store: AppStore
    @State private var selectedID: UUID?
    @State private var shareFile: ShareFile?
    var body: some View {
        NavigationStack {
            List {
                Section("Borçlu kullanıcılar") {
                    ForEach(store.data.people.filter { store.balance($0.id) > 0.005 }) { p in
                        HStack {
                            VStack(alignment: .leading) { Text(p.name).font(.headline); Text("\(p.plate) • \(store.balance(p.id).tl)").font(.caption).foregroundStyle(.secondary) }
                            Spacer()
                            Button("3 Günlük Bildirim") { selectedID = p.id }.buttonStyle(.bordered).font(.caption)
                        }
                    }
                }
                Section("Oluşturulan bildirimler") {
                    ForEach(store.data.notices.sorted { $0.issuedAt > $1.issuedAt }) { notice in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(store.person(notice.personID)?.name ?? "Bilinmeyen").bold()
                            Text("\(notice.amount.tl) • Son gün: \(notice.dueAt.shortTR)").font(.caption)
                            if notice.dueAt < Date() && store.balance(notice.personID) > 0 { Text("Süresi geçti").font(.caption).foregroundStyle(.red) }
                            Button("PDF Paylaş") { export(notice) }
                        }.padding(.vertical, 4)
                    }
                }
            }.navigationTitle("Ödeme Bildirimleri")
                .confirmationDialog("Ödeme bildirimi oluşturulsun mu?", isPresented: Binding(get: { selectedID != nil }, set: { if !$0 { selectedID = nil } })) {
                    Button("Oluştur ve PDF Paylaş") {
                        guard let id = selectedID else { return }
                        let n = Notice(personID: id, issuedAt: Date(), dueAt: Calendar.current.date(byAdding: .day, value: 3, to: Date()) ?? Date(), amount: store.balance(id), note: "Şarj kullanım bedeli")
                        store.data.notices.append(n)
                        selectedID = nil
                        export(n)
                    }
                } message: { Text("3 günlük süre taslak bildirimin oluşturulduğu tarihten başlar. Gerçek tebliğ tarihi farklıysa kurum kayıtları esas alınmalıdır.") }
                .sheet(item: $shareFile) { file in ShareSheet(items: [file.url]) }
        }
    }
    private func export(_ notice: Notice) {
        guard let p = store.person(notice.personID) else { return }
        do { shareFile = ShareFile(url: try ReportMaker.makeNotice(person: p, notice: notice)) }
        catch { store.errorMessage = "PDF oluşturulamadı: \(error.localizedDescription)" }
    }
}

struct SettingsView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        NavigationStack {
            Form {
                Section("Fiyatlandırma") {
                    TextField("Varsayılan TL/kWh", value: $store.data.defaultUnitPrice, format: .number).keyboardType(.decimalPad)
                    Text("Bu değer sadece yeni eklenen kayıtlarda kullanılır. Resmî birim fiyat kurum tarafından doğrulanmalıdır.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Güvenlik ve kayıtlar") {
                    Text("Kayıtlar bu iPhone'un uygulama alanında tutulur. Çoklu kullanıcı senkronizasyonu, sunucu, otomatik e-posta ve RFID istasyonu bağlantısı bu sürümde yoktur.")
                    Text("Kurum içi kişisel veriler için dağıtımdan önce erişim kontrolü, yedekleme ve KVKK değerlendirmesi yapılmalıdır.")
                }
                Section("Sürüm") { LabeledContent("Uygulama", value: "TÜÇA Şarj iOS 1.0") }
            }.navigationTitle("Ayarlar")
        }
    }
}
