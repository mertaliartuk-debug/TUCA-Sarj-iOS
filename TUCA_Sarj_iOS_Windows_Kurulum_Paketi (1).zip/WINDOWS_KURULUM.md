# Windows bilgisayardan iPhone 15 Pro Max kurulum adımları

1. https://github.com/signup adresinden ücretsiz GitHub hesabı açın.
2. GitHub üzerinde yeni **Private** repository oluşturun.
3. Bu ZIP içindeki tüm dosyaları, gizli `.github/workflows/ios-build.yml` dahil, depoya yükleyin.
4. Actions sekmesinden **iPhone Uygulamasini Derle** > **Run workflow** seçin.
5. İşlem başarılı olursa Artifacts bölümünden **TUCA-Sarj-iPhone-IPA-imzasiz** dosyasını indirin.
6. Bu IPA **imzasızdır**; doğrudan iPhone'a yüklenmez. Windows'ta Sideloadly (https://sideloadly.io/) gibi imzalama/yükleme aracıyla kendi Apple hesabınızla yüklenmesi gerekir. Apple hesabı ile giriş ve iPhone'un bilgisayara bağlanması istenebilir.
7. iPhone'da Geliştirici Modu ve uygulamaya güvenme adımları gerekebilir. Ücretsiz hesaplarda yaklaşık 7 günde bir yeniden imzalama gerekebilir.

**Güvenlik:** Kurumun gerçek personel verilerini GitHub deposuna yüklemeyin. Kaynak kodu dışında rapor ve kişisel veri paylaşmayın. Apple parolanızı bu sohbet üzerinden paylaşmayın.

**Not:** Derleme ve iPhone'da çalıştırma bu ortamda test edilemedi. GitHub Actions ücretsiz kota ve macOS erişimi hesap durumuna bağlıdır. Uygulama kurumsal bir sistemin resmi dağıtımı değildir.
